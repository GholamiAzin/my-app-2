import './Body.css'
import Url from './Url.js';

function Body() {
    <div className='main-body'>
        <Url name={'Item1'}/>
    </div>
}

export default Body;