import './Askmenu.css';

function Askmenu() {
    <div className='ask'>
        <span className='ask-span'>People also ask :</span>
        <span className='ask-span'>What is Item1?</span>
        <span className='ask-span'>what does Item1 do?</span>
        <span className='ask-span'>who invented Item1?</span>
        <span className='ask-span'>why should i use Item1?</span>
    </div>
}
export default Askmenu;